# Prompting Engineering

1. 개념
    - AI가 원하는 결과를 생성하도록 가이드 하는 최적의 프롬프트 설계
    - LLM에서 원하는 결과를 얻기 위해 프롬프트를 정교하게 최적화하는 과정
    - 다양한 종류의 task에서 LLM의 역량을 향상시킬 수 있음
    - 복잡한 task에서도 hallucination과 같은 오류 해소에 기여
    
2. 구성요소
    - Instuction 지시 : LLM 모델이 수행해야 하는 과제나 구체적 목표 제시
    - Context 문맥 : 모델 정확도를 높이기 위해 사용될 수 있는 문제 해결에 필요한 배경 정보나 추가 문맥
    - Input data 입력 데이터 : 모델이 답해야하는 질문
    - Output Indicator 출력 지시자 : 출력 유형이나 형식과 같이 모델의 답이 어떤 방식으로 출력되어야 하는지 지정
3. 기법
    1. Zero-Shot Prompting : task에 대한 사전 예시 없이 모델이 바로 문제 해결
    One-Shot Prompting : task에 대한 1개의 예시를 제시
    Few-Shot Prompting : task에 대한 2개 이상의 예시를 제시
    2. Chain of Thought(CoT) : chain of thought 과정으로 문제 해결을 하는 예시를 제시함으로써 복잡한 중간 추론 과정을 사용하여 답을 제시하도록 만듬
    3. Zero Shot Chain of Thought : 
        
        별도의 예시 없이 chain of thought 과정을 사용하도록 유도
        
        "Let's think step be step"이라는 trigger 문장을 프롬프트에 추가
        
        [few-shot CoT와 zero-shot CoT 프롬프트 차이]
        
        ![image.png](image.png)
        
        출처 : [https://www.researchgate.net/figure/Few-shot-left-and-zero-shot-right-CoT-Both-prompts-the-LLM-to-output-intermediate_fig3_370981716](https://www.researchgate.net/figure/Few-shot-left-and-zero-shot-right-CoT-Both-prompts-the-LLM-to-output-intermediate_fig3_370981716)
        
    4. Self Consistency : few-shot CoT를 사용해 여러 형태의 추론 과정을 활용한 후 다수에 해당하는 답을 최종 결과로 제시하도록 만듬, 모델이 더 일관성 있는 답변을 선택하도록 유도 
        
        [b와 d의 차이]
        
        ![image.png](image%201.png)
        
        출처 : [https://velog.io/@xuio/SELF-CONSISTENCY-IMPROVES-CHAIN-OF-THOUGHT-REASONING-IN-LANGUAGE-MODELS](https://velog.io/@xuio/SELF-CONSISTENCY-IMPROVES-CHAIN-OF-THOUGHT-REASONING-IN-LANGUAGE-MODELS)
        
    5. Generated knowledge Prompting :  
        
        질문과 함께 모델에서 생성된 지식이나 정보를 함께 제공하는 방식
        
        지식(Knowledge)을 만드는 과정을 보여주는 프롬프트 예시를 제공하는 Few-Shot Prompting를 통해 원래의 질문과 관련된 Knowledge를 모델이 직접 생성
        
        → 기존의 질문에 생성된 Knowlegde를 추가한 프롬프트를 사용함으로써 모델이 Knowledge를 사용해 답을 제시하도록 만듬
        
        [Genereated Knowledge Prompting 매커니즘]
        
        ![image.png](image%202.png)
        
    6. Automatic Prompt Engineering : 사람이 아닌 모델이 스스로 프롬프트를 만들고 이를 활용해 답을 제시하는 방식, 프롬프트 내부에 <INSERT>라는 빈 칸을 만들고 answer를 함께 입력하여 모델이 <INSERT> 부분을 추론함으로써 프롬프트를 생성하도록 만듬
        
        [Automatic Prompt Engineering 매커니즘]
        
        ![image.png](image%203.png)
        
    7. ReAct Prompting : '생각-행동-관찰' 과정을 번갈아 수행하는 방식으로 답을 제시하도록 유도하는 방식, '생각-행동-관찰' 과정을 반복하며 주어진 질문에 대한 답을 찾아가는 문제 해결 과정을 예제로 제시하는 Few-Shot Prompting (CoT와 유사하나 생각-행동-관찰 이라는 일련의 형식화된 과정을 사용한다는 차이점)
        
        
    8. Active-Prompt : 
        
        여러 개의 질의 예시를 만들어 모델이 답변하게 한 후 모델의 답변에 대한 모호성(Uncertainty)를 평가
        
        → 모델이 답하기 어려운 것으로 보이는 질문들만 골라 사람이 직접 답변을 라벨링한 후 Few-Shot CoT의 예제로 사용하여 다시 답변하게 만드는 방식
        
        답변의 모호성은 모델에게 동일한 질문을 여러 번 제시한 후 disagreement를 계산하여 사용함, 더 효율적으로 질의-답변 예제를 만들 수 있음
        
        [Active-Prompt 매커니즘]
        
        ![image.png](image%204.png)
        
    
4. 예시 [출처 : https://www.promptingguide.ai/kr/introduction/examples]
    - Text Summarization
    
    ![](https://blog.kakaocdn.net/dna/p2EwR/btsJmO2JZtX/AAAAAAAAAAAAAAAAAAAAAPaLlkHFjyG1cqV7i-qEoB_vhDCttQba3CH_h7J5tWBf/img.png?credential=yqXZFxpELC7KVnFOS48ylbz2pIh7yKj8&expires=1753973999&allow_ip=&allow_referer=&signature=8By0cYlhRIDEOz1Ipm%2F5xRl65UU%3D)
    
    - Information Extraction
    
    ![](https://blog.kakaocdn.net/dna/bwQlsn/btsJmdWgXos/AAAAAAAAAAAAAAAAAAAAAJhivMxfahKJWGlxPr-eSJRRuEjh4PBcEsyP7AF81NXu/img.png?credential=yqXZFxpELC7KVnFOS48ylbz2pIh7yKj8&expires=1753973999&allow_ip=&allow_referer=&signature=jjWqxgK6FLB%2B63Nz4JlEBqt8vpM%3D)
    
    - Question Answering
    
    ![](https://blog.kakaocdn.net/dna/bUj9Gl/btsJlwWjGmf/AAAAAAAAAAAAAAAAAAAAAGrU1Dg7OlkdjVppTHrShnUU0ug0F_Ev13Ud6CqucFpe/img.png?credential=yqXZFxpELC7KVnFOS48ylbz2pIh7yKj8&expires=1753973999&allow_ip=&allow_referer=&signature=LLPhue8n5pBvpXVRA79EKfi0O7g%3D)
    
    - Text Classification
    
    ![](https://blog.kakaocdn.net/dna/yZmT2/btsJmaSTAXM/AAAAAAAAAAAAAAAAAAAAAGoYIvUmtSNj5VB0pEGMZZW4gRlvfgZL4qIOZl5OkTV3/img.png?credential=yqXZFxpELC7KVnFOS48ylbz2pIh7yKj8&expires=1753973999&allow_ip=&allow_referer=&signature=8t3A2y%2B%2BTISxXJAJ9%2B%2B8xs73BtM%3D)
    
    - Reasoning
    
    ![](https://blog.kakaocdn.net/dna/bgmot7/btsJnK6dJVx/AAAAAAAAAAAAAAAAAAAAANNL9P2AJOmCsNNlZI6p6nrHgohvEb3RHrfxayUP9xk6/img.png?credential=yqXZFxpELC7KVnFOS48ylbz2pIh7yKj8&expires=1753973999&allow_ip=&allow_referer=&signature=bP50K71N48KklkqLk6FZs3C%2FHP0%3D)
    
    - Conversation
    
    ![](https://blog.kakaocdn.net/dna/bwwZhS/btsJl64dnMQ/AAAAAAAAAAAAAAAAAAAAALktCkUiseTo6ZSsL-DLCru4LIs3ypXy-8p9E6HRnMEO/img.png?credential=yqXZFxpELC7KVnFOS48ylbz2pIh7yKj8&expires=1753973999&allow_ip=&allow_referer=&signature=EXoB5VOHDv6nAgJIehEHVc9gono%3D)
    
    - Code Generation
    
    ![](https://blog.kakaocdn.net/dna/bxjH0v/btsJnadok52/AAAAAAAAAAAAAAAAAAAAALL6BOZ4gkPLwWNd_b0j3_hH7Cv8jYkZPbFGY9fVAvi0/img.png?credential=yqXZFxpELC7KVnFOS48ylbz2pIh7yKj8&expires=1753973999&allow_ip=&allow_referer=&signature=PdRzJ%2FOmeseR6dYIcGNm%2F0U1NP8%3D)
    

[Reference]

https://m.blog.naver.com/gptfrontier/223337739409

https://working-helen.tistory.com/105

https://modulabs.co.kr/blog/prompt-engineering

https://blog.naver.com/gptfrontier/223338917032

https://modulabs.co.kr/blog/%ED%94%84%EB%A1%AC%ED%94%84%ED%8A%B8-%EC%97%94%EC%A7%80%EB%8B%88%EC%96%B4%EB%A7%81-%EA%B8%B0%EB%B2%95%EA%B3%BC-nlp-%EC%9E%91%EC%97%85-%EB%B6%84%EB%A5%98